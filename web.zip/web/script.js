document.getElementById('register-course').addEventListener('click', function () {
    const selectedStudents = document.querySelectorAll('.student-checkbox:checked');
    const course = document.getElementById('course-list').value;

    if (selectedStudents.length === 0) {
        alert('Please select at least one student.');
        return;
    }

    selectedStudents.forEach(student => {
        const studentName = student.value;
        addCourseToTable(studentName, course);
    });
});

function addCourseToTable(studentName, course) {
    const tableBody = document.querySelector('#course-table tbody');
    const row = document.createElement('tr');

    row.innerHTML = `
        <td>${studentName}</td>
        <td>${course}</td>
        <td class="actions">
            <button class="edit" onclick="editCourse(this)">Edit</button>
            <button class="delete" onclick="deleteCourse(this)">Delete</button>
        </td>
    `;

    tableBody.appendChild(row);
}

function editCourse(button) {
    const row = button.closest('tr');
    const studentName = row.cells[0].textContent;
    const currentCourse = row.cells[1].textContent;

    const newCourse = prompt(`Edit course for ${studentName}:`, currentCourse);
    if (newCourse) {
        row.cells[1].textContent = newCourse;
    }
}

function deleteCourse(button) {
    const row = button.closest('tr');
    row.remove();
}
// // document.getElementById('register-course').addEventListener('click', function () {
// //     const selectedStudents = document.querySelectorAll('.student-checkbox:checked');
// //     const course = document.getElementById('course-list').value;

// //     if (selectedStudents.length === 0) {
// //         alert('Please select at least one student.');
// //         return;
// //     }

// //     selectedStudents.forEach(student => {
// //         const studentName = student.value;
// //         addCourseToTable(studentName, course);
// //     });
// // });

// // function addCourseToTable(studentName, course) {
// //     const tableBody = document.querySelector('#course-table tbody');
// //     const row = document.createElement('tr');

// //     row.innerHTML = `
// //         <td>${studentName}</td>
// //         <td>${course}</td>
// //         <td class="actions">
// //             <button class="edit" onclick="editCourse(this)">Edit</button>
// //             <button class="delete" onclick="deleteCourse(this)">Delete</button>
// //         </td>
// //     `;

// //     tableBody.appendChild(row);
// // }

// // function editCourse(button) {
// //     const row = button.closest('tr');
// //     const studentName = row.cells[0].textContent;
// //     const currentCourse = row.cells[1].textContent;

// //     const newCourse = prompt(`Edit course for ${studentName}:`, currentCourse);
// //     if (newCourse) {
// //         row.cells[1].textContent = newCourse;
// //     }
// // }

// // function deleteCourse(button) {
// //     const row = button.closest('tr');
// //     row.remove();
// // }
//  //document.getElementById("title").innerText="Revised Title";
// //let currentContaine= document.getElementById("main-Container");
// // currentContainer.innerText= ("I am Somewhere");

// // currentContainer.innerHtml= <h1>"i am changed"</h1>




 



// // let myImage= document.getElementById("img");
// // myImage.src = "C:\\Users\\Sonia\\Desktop\\images.jpg"



// // let myElement= document.createElement("div");


// // let myButton= document.createElement("button");
// // myElement.appendChild(myButton);
// // document.body.appendChild(myElement);
// //myElement.remove();#course
// //let count= 0; 
// // myButton.addEventListener("click",()=>{
// // alert('i am clicked"'); 
// // });




// //   myElement.addEventListener("click",investement);
// // myElement.innerText= count;
// // function incrementCount(){
// //     return count++;
// // }
 
// // {/* <div myElement.style.backgroundColor="yellow";
// // myElement.addEventListener("mouseleave", function()
// // {
// //       myElement.style.backgroundColor = "white";
// // });
// // myButton.innerText 
// // let element=document.getElementByTagName("*");
// // console.log(element);
// // for (int i=0; i<ElementInternals.length; i++)
// //     console.log(elements[i]);
// //let element=document.querySelector("*");
// //elements.forEach();
// //document.getElementById("title").innerText = "Revised Title";
// // Code to change content in main-Container
// // console.log("Script is running");
// // let currentContainer = document.getElementById("main-Container");
// // currentContainer.innerText = "I am Somewhere";
// // currentContainer.innerHTML = "<h1>I am changed</h1>";
// //
// // let myImage = document.getElementById("img");
// // myImage.src = "images/R.png";
// // let myElement = document.createElement("div");
// // let myButton = document.createElement("button");
// // // Add text to the button for better visibility
// // myButton.innerText = "Click Me";
// // myElement.appendChild(myButton);
// // document.body.appendChild(myElement);
// // myButton.addEventListener("click", () => {
// //     alert("I am clicked");
// // });

  
// // let count = 0;

// // function incrementCount() {
// //     count++;
// //     document.getElementById('countDisplay').innerText = 'Count: ' + count;
// // }

// // // Add an event listener to the increment button
// // document.getElementById('incrementButton').addEventListener('click', incrementCount);


 




  


// // //Building an Interactive Webpage with JavaScript DOM Manipulation
// // // Create and append elements
// // let myElement = document.createElement("div");
// // let myButton = document.createElement("button");

// // // Add text to the button for better visibility
// // myButton.innerText = "Hover me";

// // // Append the button to the div and the div to the body
// // myElement.appendChild(myButton);
// // document.body.appendChild(myElement);

// // // Set initial background color and add mouseleave event listener
// // myElement.style.backgroundColor = "yellow";
// // myElement.addEventListener("mouseleave", function() {
// //     myElement.style.backgroundColor = "white";
// // });



// // Create and append elements
// let myElement = document.createElement("div");
// let myButton = document.createElement("button");

// // Add text to the button for better visibility
// myButton.innerText = "Click Me";

// // Append the button to the div and the div to the body
// myElement.appendChild(myButton);
// document.body.appendChild(myElement);

// // Add an event listener to the button
// myButton.addEventListener("click", () => {
//     alert("I am clicked");
// });

// // Set initial background color and add mouseleave event listener
// myElement.style.backgroundColor = "yellow";
// myElement.addEventListener("mouseleave", function() {
//     myElement.style.backgroundColor = "white";
// });

// // Select all elements and log them
// let elements = document.querySelectorAll("*");

// elements.forEach((el) => {
//     console.log(el);
// });

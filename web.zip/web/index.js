// fruits = ["apple", "banana", "mango"];
// fruits.push("adc");

 //console.log(fruits); // This will print the updated array

// let htmllistitem=fruits.map(val=>"<li>"+val+"</li>");
// // index.js

// // Example 1: Convert fruits to uppercase using map
// let fruits = ["apple", "banana", "mango"];
// let output1 = fruits.map(fruit => fruit.toUpperCase());
// console.log(output1);  // Output: ["APPLE", "BANANA", "MANGO"]

// // Example 2: Add text to each fruit using map
 //let output2 = fruits.map(fruit => `I like ${fruit}`);
 //console.log(output2);  // Output: ["I like apple", "I like banana", "I like mango"]

// // Example 3: Get the length of each fruit name using map
// let output3 = fruits.map(fruit => fruit.length);
// console.log(output3);  // Output: [5, 6, 5]
// values.reduce(((aa,val)=>acc*val),0);
//fruits.slice(1,4,"apricot","acd");

//object;
// let person={name:"sonia",age:20,isStudent:true};
    //console.log(person);
 
// Creating an object using the Object constructor
// person1 = new Object();
//person1.name = "Sonia";
//person1.isStudent = true;

// Creating an object using Object.create
//let person2 = Object.create(null);
//person2.name = "Sonia";

// Logging the name property of person1
//console.log(person1.name); 


//console.log(person1["name"]);
 
// Creating an empty object
// let person1 = {};  


// person1["city"] = "Faisalabad";  
// let idVal = "name";  
// person1[idVal] = "Sonia";  // Assigning a value to 'name' dynamically

// // Accessing properties
// console.log(person1[idVal]);  // Output: Sonia

// // Checking if 'city' was added successfully
// console.log(person1.city);  // Output: Faisalabad
//
//
//let person={name:"sonia",age:20,isStudent:true,registeredCourses:{course1:{title:'PF',isPassed:true}}};
    


    // let person = {
    //     name: "sonia",
    //     age: 20,
    //     isStudent: true,
    //     registeredCourses: {
    //         course1: { title: 'PF', isPassed: true },
    //         course2: { title: 'OOP', isPassed: true },
    //         course3: { title: 'DBMS', isPassed: false },
    //         course4: { title: 'DSA', isPassed: true },
    //         course5: { title: 'CN', isPassed: false }
    //     }
    // };
    
    // // Displaying the updated object
    // console.log(person);
//offered courses list,5 student namesjo stdent select by checkbox and click course and coures registered,view ,edit;

 
 
 
 
// let person = {
//     name: "sonia",
//     age: 20,
//     isStudent: true,
//     registeredCourses: {
//         course1: { title: 'PF', isPassed: true },
//         course2: { title: 'OOP', isPassed: true },
//         course3: { title: 'DBMS', isPassed: false },
//         course4: { title: 'DSA', isPassed: true },
//         course5: { title: 'CN', isPassed: false }
//     },

//     // Method to display the person's name
//     displayName: function() {
//         return this.name;
//     }
// };

// Calling the method and printing the result
//console.log(person.displayName());
//console.log(Object.keys(person));
//console.log(Object.entries(person));


// let person1 = {
//     name: "sonia",
//     age: 20,
//     isStudent: true,
//     city: "fsd"
// };

// // Destructuring `name` and `isStudent` from `person1`
// let { name, isStudent } = person1;

// // Output values
// console.log(name);        // Expected output: "sonia"
// console.log(isStudent);   // Expected output: true


// //let person1 = {
//     name: "sonia",
//     age: 20,
//     isStudent: true,
//     city: "fsd"
// };

// // Correct usage of spread operator
// let currentStudent = { ...person1, Grade: "A" };

// console.log(currentStudent);
  


//let currentStudent=(... person1);
//    (...person1,Grade:"A");
 
 
// function add(...val) {
//     let result = 0;
//     for (let count = 0; count < val.length; count++) {
//         result += val[count];
//     }
//     return result;
// }

// console.log(add(1, 2, 3, 4, 5));  // Output: 15
 
   





//    function createPerson(name, isStudent) {
//     this.name = name;
//     this.isStudent = isStudent;
// }

// // Adding properties and methods to the prototype
// createPerson.prototype.semesterStarts = true;
// createPerson.prototype.greet = function() {
//     return `Hello ${this.name}`;  // Using backticks for string interpolation
// }

// // Creating instances
// let person4 = new createPerson("sonia", true);
// let person5 = new createPerson("asma", true);

// console.log(person4.greet()); // Output: Hello sonia
// console.log(person5.greet()); // Output: Hello asma
// console.log(person4.semesterStarts); // Output: true
// console.log(person5.semesterStarts); // Output: true
//
//
//
// function f1(){
//     console.log("i am sonia")
// }();  
// //fun1();
// //Comma,terminal,udhar hi callinng


//  let greet = function(name) {
//     return `welcome ${name}`;
//  };console.log(greet("sonia")); 


// //displayduplicateitem
 
// function f1() {
//     var a = [1, 2, 4, 3, 2, 1]; 
//     var b = a[0];

//     const f2 = (a, b) => (b > 1 ? b : undefined);

//     return f2(a, b);
// }

// console.log(f1());

// function f1() {
//     var a = [1, 2, 4, 3, 2, 1]; 

//     const f2 = (element) => (element > 1 ? element : undefined);

//     return a.map(f2).filter(x => x !== undefined);
// }

// console.log(f1()); 





// //arrowfunction  use in filter ,mapping,reducing,maximum
// let nameless= (name)=>{
//     return "Hello" +name;}
// // }or
// // let nameless= (name)=>'Hello"+
//
//
//


// let multiply= function(a,b)   
// {
//     return a*b;
// }

// let add= function(a,b){
//     return a+b;
// };


// let mainplator= function(val,val,func){
//     return func(val1,val2);
// };
 //const add = (a, b) => a + b;

//callback functions main pehle execute and uske indar wala baad me(callback)
// closure
//  function counter(){
//     let count=0;
//     return function(){
//         return count++;
//     };

// };let increment= counter();
// console.log(increment());





// function f1() {
//         var a = [1, 2, 4, 3, 2, 1]; 
//         var b = a[0];
//         return f2(){
//            
// }

    
//         const f2 = (a, b) => (b > 1 ? b : undefined);
    
//         return f2(a, b);};



//jab array se 1 element chahiye use reduce and arrow function


// function mul(...val){
//     return val.reduce(((val+res)=>result*val),1);
// };
// function mul(...val) {
//     return val.reduce((result, currentVal) => result * currentVal, 1);
// }

// console.log(mul(1, 2, 3, 4)); // Output: 24

//async with await,getcount
//has execution that is time takingtaking. 
//async function mul(file){
//  await val1.openfile(file);
//settimeout(mul,2);   
//function generator task
//
//
//document
//html top element ,root,head and boddy two main tag,important function getelement()    



//let mainElement = document.getElementById(<body><h1>"element"</h1></body>);
// let webElements = document.getElementsByClassName("web");  // Corrected
// let divElements = document.getElementsByTagName("div");    // Corrected
// let classElement = document.querySelector(".class");       // Corrected
// let allElements = document.querySelectorAll(".some-class"); // Corrected (Selector should not be empty)

//console.log(mainElement);
// console.log(webElements);
// console.log(divElements);
// console.log(classElement);
// console.log(allElements);
//

// let mainElement = document.getElementById("element"); // Selects the <h1> with id="element"
// console.log(mainElement.childNode);  // Outputs the <h1> element or null if not found
// let bodyElement = document.body; // Selects the <body> element
// console.log(bodyElement); // Outputs the <body> element
  



{/* <div class="course-selection">
<h2>Select Course</h2>
<select id="course-list">
    <option value="PF">PF</option>
    <option value="OOP">OOP</option>
    <option value="DS">DS</option>
    <option value="database">Database</option>
    <option value="OS">OS</option>
</select>
<button id="register-course">Register Course</button>
</div>
// document.getElementById("title").innerText="Revised Title"; */}



// Create and append elements
let myElement = document.createElement("div");
let myButton = document.createElement("button");

// Add text to the button for better visibility
myButton.innerText = "Click Me";

// Append the button to the div and the div to the body
myElement.appendChild(myButton);
document.body.appendChild(myElement);

// Add an event listener to the button
myButton.addEventListener("click", () => {
    alert("I am clicked");
});

// Set initial background color and add mouseleave event listener
myElement.style.backgroundColor = "yellow";
myElement.addEventListener("mouseleave", function() {
    myElement.style.backgroundColor = "white";
});

// Select all elements and log them
let elements = document.querySelectorAll("*");

elements.forEach((el) => {
    console.log(el);
})
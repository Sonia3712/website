// fruits = ["apple", "banana", "mango"];
// fruits.push("adc");

 //console.log(fruits); // This will print the updated array

// let htmllistitem=fruits.map(val=>"<li>"+val+"</li>");
// // index.js

// // Example 1: Convert fruits to uppercase using map
// let fruits = ["apple", "banana", "mango"];
// let output1 = fruits.map(fruit => fruit.toUpperCase());
// console.log(output1);  // Output: ["APPLE", "BANANA", "MANGO"]

// // Example 2: Add text to each fruit using map
// let output2 = fruits.map(fruit => `I like ${fruit}`);
// console.log(output2);  // Output: ["I like apple", "I like banana", "I like mango"]

// // Example 3: Get the length of each fruit name using map
// let output3 = fruits.map(fruit => fruit.length);
// console.log(output3);  // Output: [5, 6, 5]
// values.reduce(((aa,val)=>acc*val),0);
//fruits.slice(1,4,"apricot","acd");
//
// let person={name:"sonia",age:20,isStudent:true};
    //console.log(person);
 
// Creating an object using the Object constructor
// person1 = new Object();
//person1.name = "Sonia";
//person1.isStudent = true;

// Creating an object using Object.create
//let person2 = Object.create(null);
//person2.name = "Sonia";

// Logging the name property of person1
//console.log(person1.name); 


//console.log(person1["name"]);
 
// Creating an empty object
// let person1 = {};  


// person1["city"] = "Faisalabad";  
// let idVal = "name";  
// person1[idVal] = "Sonia";  // Assigning a value to 'name' dynamically

// // Accessing properties
// console.log(person1[idVal]);  // Output: Sonia

// // Checking if 'city' was added successfully
// console.log(person1.city);  // Output: Faisalabad
//
//
//let person={name:"sonia",age:20,isStudent:true,registeredCourses:{course1:{title:'PF',isPassed:true}}};
    


    // let person = {
    //     name: "sonia",
    //     age: 20,
    //     isStudent: true,
    //     registeredCourses: {
    //         course1: { title: 'PF', isPassed: true },
    //         course2: { title: 'OOP', isPassed: true },
    //         course3: { title: 'DBMS', isPassed: false },
    //         course4: { title: 'DSA', isPassed: true },
    //         course5: { title: 'CN', isPassed: false }
    //     }
    // };
    
    // // Displaying the updated object
    // console.log(person);
//offered courses list,5 student namesjo stdent select by checkbox and click course and coures registered,view ,edit;

 
 
 
 
// let person = {
//     name: "sonia",
//     age: 20,
//     isStudent: true,
//     registeredCourses: {
//         course1: { title: 'PF', isPassed: true },
//         course2: { title: 'OOP', isPassed: true },
//         course3: { title: 'DBMS', isPassed: false },
//         course4: { title: 'DSA', isPassed: true },
//         course5: { title: 'CN', isPassed: false }
//     },

//     // Method to display the person's name
//     displayName: function() {
//         return this.name;
//     }
// };

// Calling the method and printing the result
//console.log(person.displayName());
//console.log(Object.keys(person));
//console.log(Object.entries(person));


// let person1 = {
//     name: "sonia",
//     age: 20,
//     isStudent: true,
//     city: "fsd"
// };

// // Destructuring `name` and `isStudent` from `person1`
// let { name, isStudent } = person1;

// // Output values
// console.log(name);        // Expected output: "sonia"
// console.log(isStudent);   // Expected output: true


// //let person1 = {
//     name: "sonia",
//     age: 20,
//     isStudent: true,
//     city: "fsd"
// };

// // Correct usage of spread operator
// let currentStudent = { ...person1, Grade: "A" };

// console.log(currentStudent);
  


//let currentStudent=(... person1);
//    (...person1,Grade:"A");
 
 
// function add(...val) {
//     let result = 0;
//     for (let count = 0; count < val.length; count++) {
//         result += val[count];
//     }
//     return result;
// }

// console.log(add(1, 2, 3, 4, 5));  // Output: 15
 
   





//    function createPerson(name, isStudent) {
//     this.name = name;
//     this.isStudent = isStudent;
// }

// // Adding properties and methods to the prototype
// createPerson.prototype.semesterStarts = true;
// createPerson.prototype.greet = function() {
//     return `Hello ${this.name}`;  // Using backticks for string interpolation
// }

// // Creating instances
// let person4 = new createPerson("sonia", true);
// let person5 = new createPerson("asma", true);

// console.log(person4.greet()); // Output: Hello sonia
// console.log(person5.greet()); // Output: Hello asma
// console.log(person4.semesterStarts); // Output: true
// console.log(person5.semesterStarts); // Output: true
